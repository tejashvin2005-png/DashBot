// server.js
const { MongoClient } = require('mongodb');
const client = new MongoClient(process.env.MONGO_URI);
app.post('/webhook', async (req, res) => {
  try {
    await client.connect();
    const db = client.db("chatbot"); // database name
    const users = db.collection("users"); // collection name

    const intentName = req.body.queryResult.intent.displayName;
    let responseText = "Default response";

    if (intentName === "Check Order Status") {
      const userData = await users.findOne({ userId: "1234" });
      if (userData) {
        responseText = `Hello ${userData.name}, your order is ${userData.orderStatus}`;
      } else {
        responseText = "I couldn’t find your order details.";
      }
    }

    res.json({ fulfillmentText: responseText });
  } catch (err) {
    console.error(err);
    res.json({ fulfillmentText: "There was an error processing your request." });
  }
});

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { SessionsClient } = require('@google-cloud/dialogflow');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PROJECT_ID = process.env.DIALOGFLOW_PROJECT_ID;

const sessionClient = new SessionsClient({
  keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
});

function sessionPath(sessionId) {
  return sessionClient.projectAgentSessionPath(PROJECT_ID, sessionId);
}

app.post('/api/trigger-event', async (req, res) => {
  try {
    const { sessionId, eventName, languageCode = 'en' } = req.body;
    if (!sessionId || !eventName) {
      return res.status(400).json({ error: 'sessionId and eventName are required' });
    }
    const request = {
      session: sessionPath(sessionId),
      queryInput: { event: { name: eventName, languageCode } },
    };
    const [response] = await sessionClient.detectIntent(request);
    const result = response.queryResult;
    res.json({
      intent: result.intent?.displayName || null,
      fulfillmentText: result.fulfillmentText || '',
      parameters: result.parameters || {},
      outputContexts: result.outputContexts || [],
    });
  } catch (err) {
    console.error('trigger-event error:', err);
    res.status(500).json({ error: 'Failed to trigger event', details: err.message });
  }
});

app.post('/api/query-text', async (req, res) => {
  try {
    const { sessionId, text, languageCode = 'en' } = req.body;
    if (!sessionId || !text) {
      return res.status(400).json({ error: 'sessionId and text are required' });
    }
    const request = {
      session: sessionPath(sessionId),
      queryInput: { text: { text, languageCode } },
    };
    const [response] = await sessionClient.detectIntent(request);
    const result = response.queryResult;
    res.json({
      intent: result.intent?.displayName || null,
      fulfillmentText: result.fulfillmentText || '',
      parameters: result.parameters || {},
      outputContexts: result.outputContexts || [],
    });
  } catch (err) {
    console.error('query-text error:', err);
    res.status(500).json({ error: 'Failed to query text', details: err.message });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Backend listening on http://localhost:${PORT}`);
});
const { MongoClient } = require('mongodb');
const uri = process.env.MONGO_URI; // store in .env
const client = new MongoClient(uri);

app.post('/webhook', async (req, res) => {
  await client.connect();
  const db = client.db("chatbot");
  const users = db.collection("users");

  const intentName = req.body.queryResult.intent.displayName;
  let responseText = "Default response";

  if (intentName === "Check Order Status") {
    const userData = await users.findOne({ userId: "1234" });
    responseText = `Hello ${userData.name}, your order is ${userData.orderStatus}`;
  }

  res.json({ fulfillmentText: responseText });
});
